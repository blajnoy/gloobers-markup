$("#stickedAsideBox").sticky({
    topSpacing: 30,
    bottomSpacing: $('.footer').outerHeight() + 30
});