$(document).ready(function () {

    $('.lnk-filter').on('click', function (e) {
        e.preventDefault();

        $(this).toggleClass('up')
    });
    
});
